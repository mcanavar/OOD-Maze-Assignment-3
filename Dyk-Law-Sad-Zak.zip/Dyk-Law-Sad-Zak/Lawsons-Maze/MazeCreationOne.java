import java.util.List;
import java.util.ArrayList;

public class MazeCreationOne implements RectMaze
{  
    MazeMaker newmaze;
    public int getMaxX(){
        return 5;
    }
    public int getMaxY(){
        return 5;
    }
    public List<DirType> getDirections(int x, int y){
        this.newmaze = new MazeMaker();
        newmaze.CreateMaze(x, y);
        String[][] Maze = newmaze.CreateMaze(x, y);
        List<DirType> listo = new ArrayList<DirType>();
        for (int row = 1; row < Maze.length; row++) {
            for (int col = 1; col < Maze[row].length; col++) {
                if (Maze[row][col] == " |")
                {listo.add(DirType.South);}
                if (Maze[row][col] == "_ ")
                {listo.add(DirType.East);}
                if (Maze[row][col] == "  ")
                {listo.add(DirType.South); listo.add(DirType.East);}
            }
        }
        return listo;
    }
}