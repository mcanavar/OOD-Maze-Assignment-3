
class RunLawson {
	
public static void main(String [] args)
	{

		MazeMaker m = new MazeMaker();
		m.CreateMaze(25,25);


	}
}