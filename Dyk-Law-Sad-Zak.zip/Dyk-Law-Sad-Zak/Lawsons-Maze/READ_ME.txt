Compile all files and then run LawsonRun. 
This will print a maze to the screen.