import java.util.ArrayList;
class NaviTest {
	





public static void main(String [] args)
	{
MazeCreation2 bob = new MazeCreation2(10, 10);

//bo.mazeCreation2(10, 10);

String[][] twoD = new String[10][10];
//ArrayList<Square> path = bob.getPath();


//path = getPath(startSquare, endSquare);
//System.out.print("\npath 0\n"+ path.get(2).xPos + " " + path.get(2).yPos);



        for(int i = 0; i < 10; i++){

            for(int j=0; j < 10; j++){
               

}}

        for(int i = 0; i < twoD.length ; i++){
        	//System.out.print("\n");
            for(int j=0; j < twoD[i].length ; j++){
              //  System.out.print(twoD[i][j] );

	}
}
}
}