import java.util.ArrayList;
import javafx.scene.shape.Shape;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
class NaviTest2 {
	
public static void main(String [] args)
	{




	}
}