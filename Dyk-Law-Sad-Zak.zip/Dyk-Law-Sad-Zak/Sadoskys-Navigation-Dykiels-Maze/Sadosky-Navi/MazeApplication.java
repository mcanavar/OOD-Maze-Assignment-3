import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Line;
import javafx.scene.layout.VBox;

import javafx.scene.text.*;

public class MazeApplication extends Application{
    RectMaze the_maze;
    Canvas maze_canvas;
    
    //The start function just sets up the main window for the application
    //We will discuss JavaFx later in the term
    public void start(Stage primaryStage){
        primaryStage.setTitle("A Maze");
        Group root = new Group();
        maze_canvas = new Canvas(1200, 800);
        
        root.getChildren().add(maze_canvas);

        primaryStage.setScene(new Scene(root, 1200, 800, Color.WHITE));
        primaryStage.show();
   // Line line1 = new Line(20, 30,   500,   30);
   // Line line2 = new Line(20, 47,   500,   47);

  MazeCreation2 the_maze = new MazeCreation2(20, 20); //best to leave this at 20 and 20
   // for(int i = 0; i < the_maze.lineArray.length; i++){
  //      root.getChildren().add(the_maze.lineArray[0]);
       // System.out.print("0th thing " + the_maze.lineArray[0] + "\n");
  //  };
   // maze_canvas.lineArray
      Text t = new Text(400, 50, "Start at black cube\n\nEnd at red cube\n\nGo up or down a level at blue square");
      t.setFont(new Font(20));
      root.getChildren().add(t);

  
   // root.getChildren().add(line1);
   // root.getChildren().add(line2);
   for(int i = 0; i < the_maze.path.size(); i++){
        root.getChildren().add(the_maze.lineArray[i]);   //add my lines to the party

}

 


    MazeDisplayGraphics.SIZE=400;
        MazeDisplayGraphics.MARGIN=20;

    MazeDisplayGraphics.display(the_maze, maze_canvas);
    }

    //Here is where the maze is created
    //... Replace TestMaze with a class you have created!
    void displayTheMaze(){

    }

}
//square is 17 pixels
//bottom of 20 square maze is at pixel 380
	